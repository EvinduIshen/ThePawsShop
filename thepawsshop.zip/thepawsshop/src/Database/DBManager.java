/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Database;


import Classess.PetSupplies;
import Classess.User;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.swing.JOptionPane;

/**
 *
 * @author DELL
 */
public class DBManager {
    
    public static String userName;
    public static String role;
    
    public boolean regUser(User user) {
        DBConnector dbCon = new DBConnector();
        Connection con = dbCon.getConnection();
        
        try {
            PreparedStatement statement = con.prepareStatement("Insert into user (EmpNo, UserName, Pass, Role, FullName, ExtNo, Email) values (?,?,?,?,?,?,?)");
            statement.setString(1, user.getEmpNo());
            statement.setString(2, user.getUserName());
            statement.setString(3, user.getPass());
            statement.setString(4, user.getRole());
            statement.setString(5, user.getFullName());
            statement.setString(6, user.getExtNo());
            statement.setString(7, user.getEmial());
            statement.execute();
            con.close();
            return true;
        } catch (SQLException ex) {
            Logger.getLogger(DBConnector.class.getName()).log(Level.SEVERE, null, ex);
        }
        
        return false;
    }
    
    public boolean validateUser(User user) {
        DBConnector dbCon = new DBConnector();
        Connection con = dbCon.getConnection(); 
        
        try {
            Statement statement = con.createStatement();
            ResultSet rs = statement.executeQuery("select * from user where UserName = '"+user.getUserName()+"' and Pass = '"+user.getPass()+"'");
            if(rs.next()){
                
                userName = rs.getString("UserName");
                role = rs.getString("Role");
                
                con.close();
                return true;
            } else{
                con.close();
                return false;
            }
            
        } catch (SQLException ex) {
            Logger.getLogger(DBManager.class.getName()).log(Level.SEVERE, null, ex);
        }
        return false;
    }

    public User searchUser(User user) {
        DBConnector dbCon = new DBConnector();
        Connection con = dbCon.getConnection();
        
        User emp = null;
        try {
            Statement statement = con.createStatement();
            ResultSet rs = statement.executeQuery("select * from user where EmpNo = '"+user.getEmpNo()+"'");
            if(rs.next()){
                
                emp = new User(rs.getString("UserName"), rs.getString("Pass"), rs.getString("Role"), rs.getString("EmpNo"), rs.getString("FullName"), rs.getString("ExtNo"), rs.getString("Email"));
                return emp;
                
            }
            
        } catch (SQLException ex) {
            Logger.getLogger(DBManager.class.getName()).log(Level.SEVERE, null, ex);
        }
        return emp;
    }

    public boolean updateUser(User user) {
        DBConnector dbCon = new DBConnector();
        Connection con = dbCon.getConnection();
        
        try {
            PreparedStatement statement = con.prepareStatement("update user set UserName = ?, Pass = ?, Role = ?, FullName = ?, ExtNo = ?, Email = ? where EmpNo = ?");
            statement.setString(1, user.getUserName());
            statement.setString(2, user.getPass());
            statement.setString(3, user.getRole());
            statement.setString(4, user.getFullName());
            statement.setString(5, user.getExtNo());
            statement.setString(6, user.getEmial());
            statement.setString(7, user.getEmpNo());
            statement.execute();
            con.close();
            return true;
        } catch (SQLException ex) {
            Logger.getLogger(DBConnector.class.getName()).log(Level.SEVERE, null, ex);
        }
        
        return false;
    }

    public boolean deleteUser(User user) {
        DBConnector dbCon = new DBConnector();
        Connection con = dbCon.getConnection();
        
        try {
            PreparedStatement statement = con.prepareStatement("delete from user where EmpNo = ?");
            statement.setString(1, user.getEmpNo());
            
            statement.execute();
            con.close();
            return true;
            
        } catch (SQLException ex) {
            Logger.getLogger(DBManager.class.getName()).log(Level.SEVERE, null, ex);
        }
        return false;
    }

    public boolean addsupplies(PetSupplies Petsupplies) {
        DBConnector dbCon = new DBConnector();
        Connection con = dbCon.getConnection();
        
        try {
            PreparedStatement statement = con.prepareStatement("Insert into Supplies (categoryNo, productName, Description, MfgDate, ExpDate, SupplierName, SupplierEmail) values (?,?,?,?,?,?,?)");
         
            statement.setString(1, Petsupplies.getcategoryNo());
            statement.setString(2, Petsupplies.getProductName());
            statement.setString(3, Petsupplies.getDescription());
            statement.setString(4, Petsupplies.getMfgDate());
            statement.setString(5, Petsupplies.getExpDate());
            statement.setString(6, Petsupplies.getSupplierName());
            statement.setString(7, Petsupplies.getSupplierEmail());
            statement.execute();
            con.close();
            return true;
        } catch (SQLException ex) {
            Logger.getLogger(DBConnector.class.getName()).log(Level.SEVERE, null, ex);
        }
        
        return false;    
    }

    public PetSupplies searchPetSupplies(PetSupplies petsupplies) {
        DBConnector dbCon = new DBConnector();
        Connection con = dbCon.getConnection();
        
        PetSupplies pt = null;
        try {
            Statement statement = con.createStatement();
            ResultSet rs = statement.executeQuery("select * from Supplies where categoryNo = '"+petsupplies.getcategoryNo()+"'");
            if(rs.next()){
                
                pt = new PetSupplies(rs.getString("categoryNo"), rs.getString("productName"), rs.getString("Description"), rs.getString("MfgDate"), rs.getString("ExpDate"), rs.getString("SupplierName"), rs.getString("SupplierEmail"));
                return pt;
                
            } 
            
            
        } catch (SQLException ex) {
            Logger.getLogger(DBManager.class.getName()).log(Level.SEVERE, null, ex);
        }
        return pt;
        
    } 


    public boolean updatePetSupplies(PetSupplies PetSupplies) {
        DBConnector dbCon = new DBConnector();
        Connection con = dbCon.getConnection();
        
        try {
            PreparedStatement statement = con.prepareStatement("update Supplies set productName = ?, Description = ?, MfgDate = ?, ExpDate = ?, SupplierName = ?, SupplierEmail = ? where categoryNo = ? ");
            statement.setString(1, PetSupplies.getProductName());
            statement.setString(2, PetSupplies.getDescription());
            statement.setString(3, PetSupplies.getMfgDate());
            statement.setString(4, PetSupplies.getExpDate());
            statement.setString(5, PetSupplies.getSupplierName());
            statement.setString(6, PetSupplies.getSupplierEmail());
            statement.setString(7, PetSupplies.getcategoryNo());
            statement.execute();
            con.close();
            return true;
        } catch (SQLException ex) {
            Logger.getLogger(DBConnector.class.getName()).log(Level.SEVERE, null, ex);
        }
        
        return false;
        
    }

    public boolean deletePetSupplies(PetSupplies PetSupplies) {
        DBConnector dbCon = new DBConnector();
        Connection con = dbCon.getConnection();
        
        try {
            PreparedStatement statement = con.prepareStatement("delete from Supplies where categoryNo = ?");
            statement.setString(1, PetSupplies.getcategoryNo());
            
            statement.execute();
            con.close();
            return true;
            
        } catch (SQLException ex) {
            Logger.getLogger(DBManager.class.getName()).log(Level.SEVERE, null, ex);
        }
        return false;
    }

    public ArrayList<PetSupplies> getAllsupplies() {
        DBConnector dbCon = new DBConnector();
        Connection con = dbCon.getConnection();

        ArrayList<PetSupplies> suppliesList = new ArrayList<PetSupplies>();

        try {
            Statement stmt = con.createStatement();
            ResultSet rs = stmt.executeQuery("select * from Supplies");
            while (rs.next()) {

                PetSupplies AC = new PetSupplies();

                AC.setCategoryNo(rs.getString("Supplies.categoryNo"));
                AC.setProductName(rs.getString("Supplies.productName"));
                AC.setDescription(rs.getString("Supplies.Description"));
                AC.setMfgDate(rs.getString("Supplies.MfgDate"));
                AC.setExpDate(rs.getString("Supplies.ExpDate"));
                AC.setSupplierName(rs.getString("Supplies.SupplierName"));
                AC.setSupplierEmail(rs.getString("Supplies.SupplierEmail"));



                suppliesList.add(AC);
            }

        } catch (SQLException ex) {
            Logger.getLogger(DBManager.class.getName()).log(Level.SEVERE, null, ex);
        }
        return suppliesList;
    }

    public ArrayList<User> getAllUsers() {
        DBConnector dbCon = new DBConnector();
        Connection con = dbCon.getConnection();

        ArrayList<User> userList = new ArrayList<User>();

        try {
            Statement stmt = con.createStatement();
            ResultSet rs = stmt.executeQuery("select * from user");
            while (rs.next()) {

                User AU = new User();

                AU.setEmpNo(rs.getString("user.EmpNo"));
                AU.setUserName(rs.getString("user.UserName"));
                AU.setRole(rs.getString("user.Role"));
                AU.setFullName(rs.getString("user.FullName"));
                AU.setExtNo(rs.getString("user.ExtNo"));
                AU.setEmial(rs.getString("user.Email"));



                userList.add(AU);
            }

        } catch (SQLException ex) {
            Logger.getLogger(DBManager.class.getName()).log(Level.SEVERE, null, ex);
        }
        return userList;
    }

    



    
}
