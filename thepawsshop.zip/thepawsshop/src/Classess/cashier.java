/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Classess;

/**
 *
 * @author Evindu
 */


public class cashier extends User {
    
    private String CashierId;
    private String CashierName;
    private String ExtNo;

    public cashier(String CashierId, String CashierName, String ExtNo) {
        this.CashierId = CashierId;
        this.CashierName = CashierName;
        this.ExtNo = ExtNo;
    }

    public String getCashierId() {
        return CashierId;
    }

    public void setCashierId(String CashierId) {
        this.CashierId = CashierId;
    }

    public String getCashierName() {
        return CashierName;
    }

    public void setCashierName(String CashierName) {
        this.CashierName = CashierName;
    }

        @Override
    public String getExtNo() {
        return ExtNo;
    }

        @Override
    public void setExtNo(String ExtNo) {
        this.ExtNo = ExtNo;
    }
    
    
    
}
