/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Classess;

/**
 *
 * @author Evindu
 */
public class Manager extends User {
    
 private String ManagerId;
 private String ManagerName;
 private String ExtNo;
 
   public Manager(String ManagerId, String ManagerName, String ExtNo) {
        this.ManagerId = ManagerId;
        this.ManagerName = ManagerName;
        this.ExtNo = ExtNo;
    }

    public String getManagerId() {
        return ManagerId;
    }

    public void setManagerId(String ManagerId) {
        this.ManagerId = ManagerId;
    }

    public String getManagerName() {
        return ManagerName;
    }

    public void setManagerName(String ManagerName) {
        this.ManagerName = ManagerName;
    }

 @Override
    public String getExtNo() {
        return ExtNo;
    }

 @Override
    public void setExtNo(String ExtNo) {
        this.ExtNo = ExtNo;
    }

  
    
}
