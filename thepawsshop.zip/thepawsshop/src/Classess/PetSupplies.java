/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Classess;

/**
 *
 * @author DELL
 */
public class PetSupplies {
    private String categoryNo;
    private String ProductName;
    private String Description;
    private String MfgDate;
    private String ExpDate;
    private String SupplierName;
    private String SupplierEmail;
    
    public PetSupplies(String categoryNo, String ProductName, String Description, String MfgDate, String ExpDate, String SupplierName, String SupplierEmail) {
        this.categoryNo = categoryNo;
        this.ProductName = ProductName;
        this.Description = Description;
        this.MfgDate = MfgDate;
        this.ExpDate = ExpDate;
        this.SupplierName = SupplierName;
        this.SupplierEmail = SupplierEmail;
        
}

    public PetSupplies(String categoryNo) {
        this.categoryNo = categoryNo;
    }

    public PetSupplies() {
        
    } 
    public String getcategoryNo() {
        return categoryNo;
    }

    public void setCategoryNo(String categoryNo) {
        this.categoryNo = categoryNo;
    }

    public String getProductName() {
        return ProductName;
    }

    public void setProductName(String ProductName) {
        this.ProductName = ProductName;
    }

    public String getDescription() {
        return Description;
    }

    public void setDescription(String Description) {
        this.Description = Description;
    }

    public String getMfgDate() {
        return MfgDate;
    }

    public void setMfgDate(String MfgDate) {
        this.MfgDate = MfgDate;
    }

    public String getExpDate() {
        return ExpDate;
    }

    public void setExpDate(String ExpDate) {
        this.ExpDate = ExpDate;
    }

    public String getSupplierName() {
        return SupplierName;
    }

    public void setSupplierName(String SupplierName) {
        this.SupplierName = SupplierName;
    }

    public String getSupplierEmail() {
        return SupplierEmail;
    }

    public void setSupplierEmail(String SupplierEmail) {
        this.SupplierEmail = SupplierEmail;
    }

    
}